class Imobiliaria:
    __slots__ = ['__quantidade', '__imoveis']

    def __init__(self) -> None:
        self.__quantidade = 0
        self.__imoveis = []

    @property
    def quantidade(self) -> int:
        return self.__quantidade

    @quantidade.setter
    def quantidade(self, quantidade) -> None:
        self.__quantidade = quantidade

    def inserir(self, imovel):
        self.__imoveis.append(imovel)
        # self.quantidade += 1

    def remover(self, imovel) -> bool:
        pass

    def alugar(self, imovel) -> bool:
        pass

    def devolver(self, imovel) -> bool:
        pass

    def get_quantidade(self) -> int:
        pass

    def listar_imoveis(self, filtro: str = '') -> str:
        for imovel in self.__imoveis:
            if imovel.regiao == filtro:
                print(f"Código: {imovel.codigo}\n"
                      f"Área: {imovel.area}\n"
                      f"Região: {imovel.regiao}\n"
                      f"Disponível: {imovel.disponivel}\n")
            if filtro == '':
                print(f"Código: {imovel.codigo}\n"
                      f"Área: {imovel.area}\n"
                      f"Região: {imovel.regiao}\n"
                      f"Disponível: {imovel.disponivel}\n")
