from imobiliaria import Imobiliaria
from residencia import Residencia
from escritorio import Escritorio

residencia = Residencia(2, 'leste', 34, True, 2)

print(residencia)





