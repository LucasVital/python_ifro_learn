class Escritorio:
    __slots__ = ['__area_util']

    def __init__(self, area_util: int) -> None:
        self.__area_util = area_util

    @property
    def area_util(self) -> int:
        return self.__area_util

    @area_util.setter
    def area_util(self, area_util):
        self.__area_util = area_util

    def __eq__(self, other) -> bool:
        if self.area_util == other.area_util:
            return True
        else:
            return False

    def __str__(self) -> str:
        return super().__str__() + f"Area útil: { self.area_util } \n"
